import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowTweetsPageComponent } from './show-tweets-page.component';

describe('ShowTweetsPageComponent', () => {
  let component: ShowTweetsPageComponent;
  let fixture: ComponentFixture<ShowTweetsPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowTweetsPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowTweetsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
