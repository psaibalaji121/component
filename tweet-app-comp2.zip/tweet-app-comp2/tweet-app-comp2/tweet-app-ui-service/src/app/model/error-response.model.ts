export class ErrorResponse {
    response : string | undefined;
}
