export class NewPassword {
    newPassword :  string;
    contact : string;
    constructor(newPassword: string, contact: string){
        this.newPassword = newPassword;
        this.contact = contact;
    }
}
