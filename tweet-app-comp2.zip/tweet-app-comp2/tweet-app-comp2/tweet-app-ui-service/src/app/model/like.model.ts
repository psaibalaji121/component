export class Like {
    tweetId : number | undefined;
    username  :  string | undefined;
}
