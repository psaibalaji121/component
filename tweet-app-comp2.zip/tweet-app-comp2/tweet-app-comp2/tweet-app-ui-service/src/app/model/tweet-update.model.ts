export class TweetUpdate {
    tweetId : string;
    tweetText : string;
    constructor(tweetId: string , tweetText: string){
        this.tweetId = tweetId;
        this.tweetText = tweetText;
    }
}
