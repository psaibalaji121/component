import { Comment } from "./comment.model";

export class TweetResponse {
    tweetId : string | undefined;
    username : string | undefined;
    tweetText : string | undefined;
    firstName : string | undefined;
    lastName : string | undefined;
    likesCount : number | undefined;
    commentsCount : number | undefined;
    likeStatus : boolean | undefined;
    comments: Array<Comment> = [];
}
