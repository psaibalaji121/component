export class Comment {
    replies : string | undefined;
    username  :  string | undefined;
}
