export class Reply {
    comment : string;
    constructor(comment: string){
        this.comment = comment;
    }
}
