import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { LoginPageComponent } from './login-registration-container/login-page/login-page.component';
import { RegistrationPageComponent } from './login-registration-container/registration-page/registration-page.component';
import { ForgotPasswordComponent } from './login-registration-container/forgot-password/forgot-password.component';
import { PostTweetsPageComponent } from './user-activity-container/post-tweets-page/post-tweets-page.component';
import { ProfileActionsComponent } from './user-activity-container/profile-actions/profile-actions.component';
import { ShowTweetsPageComponent } from './user-activity-container/show-tweets-page/show-tweets-page.component';
import { UserSideBarComponent } from './user-activity-container/user-side-bar/user-side-bar.component';
import { UserScrollTopComponent } from './user-activity-container/user-scroll-top/user-scroll-top.component';
import { ViewUsersPageComponent } from './user-activity-container/view-users-page/view-users-page.component';
import { ViewUsersTweetsComponent } from './user-activity-container/view-users-tweets/view-users-tweets.component';

@NgModule({
  declarations: [
    AppComponent,
    ErrorPageComponent,
    LoginPageComponent,
    RegistrationPageComponent,
    ForgotPasswordComponent,
    PostTweetsPageComponent,
    ProfileActionsComponent,
    ShowTweetsPageComponent,
    UserSideBarComponent,
    UserScrollTopComponent,
    ViewUsersPageComponent,
    ViewUsersTweetsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
