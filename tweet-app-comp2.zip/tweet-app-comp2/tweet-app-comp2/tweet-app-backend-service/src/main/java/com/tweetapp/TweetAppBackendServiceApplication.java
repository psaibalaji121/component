package com.tweetapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TweetAppBackendServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TweetAppBackendServiceApplication.class, args);
	}

}
