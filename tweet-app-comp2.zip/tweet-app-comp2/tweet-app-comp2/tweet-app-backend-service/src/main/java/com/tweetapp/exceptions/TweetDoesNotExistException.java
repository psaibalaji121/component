package com.tweetapp.exceptions;

public class TweetDoesNotExistException extends Exception {

    public TweetDoesNotExistException(String message) {
        super(message);
    }

}
