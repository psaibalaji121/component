package com.tweetapp.model;

import com.tweetapp.dto.Comment;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Document(collection = "tweets")
public class Tweet {

    @Id
    private String tweetId;
    private String username;
    private String tweetText;
    private String firstName;
    private String lastName;
    private String tweetDate;
    private List<String> likes = new ArrayList<>();
    private List<Comment> comments = new ArrayList<>();

}
