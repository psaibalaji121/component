package com.tweetapp.controller;

import com.tweetapp.config.metrics.AppMetrics;
import com.tweetapp.config.metrics.Constants;
import com.tweetapp.dto.AuthenticationRequest;
import com.tweetapp.dto.AuthenticationResponse;
import com.tweetapp.exceptions.UsernameAlreadyExistsException;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserOperationsService;
import io.micrometer.core.instrument.MeterRegistry;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Log4j2
@RequestMapping("/api/v1.0/")
public class UserAuthController {

    private final UserOperationsService userModelService;

    private final MeterRegistry meterRegistry;

    private final AuthenticationManager authenticationManager;

    public UserAuthController(@Qualifier("user-model-service") UserOperationsService userModelService,
                              MeterRegistry meterRegistry,
                              AuthenticationManager authenticationManager) {
        this.userModelService = userModelService;
        this.meterRegistry = meterRegistry;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/tweets/register")
    @Operation(summary = "Api to register a user")
    public ResponseEntity<?> subscribeClient(@RequestBody UserModel userModel) {

        try {
            UserModel savedUser = userModelService.createUser(userModel);
            return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
        } catch (UsernameAlreadyExistsException e) {
            return new ResponseEntity<>(new AuthenticationResponse("Given userId/email already exists"), HttpStatus.CONFLICT);
        } catch (Exception e) {
            return new ResponseEntity<>(new AuthenticationResponse(Constants.APP_ISSUE),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping("/tweets/login")
    @Operation(summary = "Api to login a user")
    public ResponseEntity<?> authenticateClient(@RequestBody AuthenticationRequest authenticationRequest) {
        String username = authenticationRequest.getUsername();
        String password = authenticationRequest.getPassword();
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
            log.debug("successfully logged in with userName: {}", username);
            meterRegistry.counter(AppMetrics.LOGIN).increment();
        } catch (Exception e) {
            return new ResponseEntity<>(new AuthenticationResponse("Bad Credentials " + username), HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<>(userModelService.findByUsername(username), HttpStatus.OK);
    }
}
