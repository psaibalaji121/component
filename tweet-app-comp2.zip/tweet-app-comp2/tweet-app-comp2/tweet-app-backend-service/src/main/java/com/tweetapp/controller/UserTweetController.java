package com.tweetapp.controller;

import com.tweetapp.config.metrics.Constants;
import com.tweetapp.dto.ErrorResponse;
import com.tweetapp.dto.Reply;
import com.tweetapp.dto.TweetUpdate;
import com.tweetapp.exceptions.InvalidUsernameException;
import com.tweetapp.exceptions.TweetDoesNotExistException;
import com.tweetapp.model.Tweet;
import com.tweetapp.service.TweetService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Log4j2
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1.0/")
public class UserTweetController {


    private final TweetService tweetService;


    public UserTweetController(@Qualifier("tweet-service") TweetService tweetService) {
        this.tweetService = tweetService;
    }

    @PostMapping(value = "/tweets/{username}/add")
    @Operation(summary = "Api to post a new tweet")
    public ResponseEntity<?> postNewTweet(@PathVariable("username") String username, @RequestBody Tweet newTweet) {
        return new ResponseEntity<>(tweetService.postNewTweet(username, newTweet), HttpStatus.CREATED);

    }

    @GetMapping(value = "/tweets/all")
    @Operation(summary = "Api to fetch all tweets")
    public ResponseEntity<?> getAllTweets() {

        try {
            log.debug("getting all the tweets..");
            return new ResponseEntity<>(tweetService.getAllTweets(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/tweets/{username}")
    @Operation(summary = "Api to fetch tweets of a user")
    public ResponseEntity<?> getUserTweets(@PathVariable("username") String username,
                                           @RequestHeader(value = "loggedInUser") String loggedInUser) {
        try {
            log.debug("getting the tweets for user: {}", username);
            return new ResponseEntity<>(tweetService.getUserTweets(username, loggedInUser), HttpStatus.OK);
        } catch (InvalidUsernameException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.INVALID_PARAM), HttpStatus.UNPROCESSABLE_ENTITY);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/tweets/{username}/{tweetId}")
    @Operation(summary = "Api to fetch details of a tweet")
    public ResponseEntity<?> getTweetDetails(@PathVariable("username") String username,
                                             @PathVariable("tweetId") String tweetId) {
        try {
            log.debug("getting the tweet details for user: {}", username);
            return new ResponseEntity<>(tweetService.getTweet(tweetId, username), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Method to update a tweet
    @PutMapping(value = "/tweets/{username}/update")
    @Operation(summary = "Api to update a tweet")
    public ResponseEntity<?> updateTweet(@PathVariable("username") String userId,
                                         @RequestBody TweetUpdate tweetUpdate) {
        try {
            log.debug("updating the tweet for user: {}", userId);
            return new ResponseEntity<>(tweetService.updateTweet(userId, tweetUpdate.getTweetId(), tweetUpdate.getTweetText()), HttpStatus.OK);
        } catch (TweetDoesNotExistException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.TWEET_ISSUE), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Method to delete a tweet
    @DeleteMapping(value = "/tweets/{username}/delete")
    @Operation(summary = "Api to delete a tweet")
    public ResponseEntity<?> deleteTweet(@PathVariable("username") String userId,
                                         @RequestHeader(value = "tweetId") String tweetId) {
        try {
            log.debug("deleting tweet for user: {}", userId);
            return new ResponseEntity<>(tweetService.deleteTweet(tweetId), HttpStatus.OK);
        } catch (TweetDoesNotExistException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.TWEET_ISSUE), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Post tweets Like
    @PostMapping(value = "/tweets/{username}/like/{tweetId}")
    @Operation(summary = "Api to delete a tweet")
    public ResponseEntity<?> likeATweet(@PathVariable("username") String username,
                                        @PathVariable(value = "tweetId") String tweetId) {
        try {
            log.debug("liking tweet for user: {}", username);
            return new ResponseEntity<>(tweetService.likeTweet(username, tweetId), HttpStatus.OK);
        } catch (TweetDoesNotExistException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.TWEET_ISSUE), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // dislike a tweet
    @PostMapping(value = "/tweets/{username}/dislike/{tweetId}")
    @Operation(summary = "Api to dislike a tweet")
    public ResponseEntity<?> dislikeATweet(@PathVariable("username") String username,
                                           @PathVariable(value = "tweetId") String tweetId) {
        try {
            log.debug("disliking tweet for user: {}", username);
            return new ResponseEntity<>(tweetService.dislikeTweet(username, tweetId), HttpStatus.OK);
        } catch (TweetDoesNotExistException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.TWEET_ISSUE), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Post tweet comment
    @PostMapping(value = "/tweets/{username}/reply/{tweetId}")
    @Operation(summary = "Api to reply a tweet")
    public ResponseEntity<?> replyToTweet(@PathVariable("username") String userId,
                                          @PathVariable("tweetId") String tweetId, @RequestBody Reply tweetReply) {
        try {
            log.debug("replying to the tweet for user: {}", userId);
            return new ResponseEntity<>(tweetService.replyTweet(userId, tweetId, tweetReply.getComment()), HttpStatus.OK);
        } catch (TweetDoesNotExistException e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.TWEET_ISSUE), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(new ErrorResponse(Constants.APP_ISSUE), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}