package com.tweetapp.controller;

import com.tweetapp.dto.AuthenticationResponse;
import com.tweetapp.dto.NewPassword;
import com.tweetapp.service.UserOperationsService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Log4j2
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1.0/")
public class UserController {

    private final UserOperationsService userModelService;

    public UserController(@Qualifier("user-model-service") UserOperationsService userModelService) {
        this.userModelService = userModelService;
    }

    @PutMapping(value = "/tweets/{username}/forgot")
    @Operation(summary = "Api to change password")
    public ResponseEntity<?> changePassword(@PathVariable("username") String username,
                                            @RequestBody NewPassword newPassword) {
        try {
            log.debug("changing password for user: {}", username);
            return new ResponseEntity<>(userModelService.changePassword(username, newPassword.getNewPassword(), newPassword.getContact()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new AuthenticationResponse("Unable to change password"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/tweets/users/all")
    @Operation(summary = "Api to fetch the details of all users")
    public ResponseEntity<?> getAllUsers() {
        log.debug("fetching total users");
        return new ResponseEntity<>(userModelService.getAllUsers(), HttpStatus.OK);

    }

    @GetMapping(value = "/tweets/user/search/{username}")
    @Operation(summary = "Api to search users by username")
    public ResponseEntity<?> searchForUsers(@PathVariable String username) {
        log.debug("fetching user by userName: {}", username);
        return new ResponseEntity<>(userModelService.getUsersByUsername(username), HttpStatus.OK);
    }
}
