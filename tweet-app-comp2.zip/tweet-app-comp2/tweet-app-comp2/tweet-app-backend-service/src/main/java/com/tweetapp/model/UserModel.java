package com.tweetapp.model;


import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Document(collection = "users")
public class UserModel {

    @Id
    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String contactNum;
    private String password;

}
