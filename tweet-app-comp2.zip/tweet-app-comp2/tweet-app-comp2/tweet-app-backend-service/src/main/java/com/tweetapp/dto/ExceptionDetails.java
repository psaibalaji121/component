package com.tweetapp.dto;

import lombok.Data;

import java.util.Date;

@Data
public class ExceptionDetails {

    private final String shortMessage;
    private final String longMessage;
    private final String resourcePath;
    private final Date timeStamp;

    public ExceptionDetails(final String pShortMessage, final String pLongMessage,
                            final String pResourcePath, final Date pTimeStamp) {
        shortMessage = pShortMessage;
        longMessage = pLongMessage;
        resourcePath = pResourcePath;
        timeStamp = pTimeStamp;
    }

}
