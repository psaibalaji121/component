package com.tweetapp.service;

import java.util.List;

import com.tweetapp.entity.Users;
import com.tweetapp.requests.CreateUserRequest;

public interface UserService {

	public void addUser(CreateUserRequest userRequest);
	
	public boolean isEmailExists(String email);
	
	public boolean isUserNameAndPasswordExists(String username, String password);
	
	public Users findUserByEmail(String email);
	
	public List<Users> getAllUsers();
	
	public void updatePassword(String email, String password);
	
	public void loginUser(String email);
	
	public void logoutUser(String email);
}
