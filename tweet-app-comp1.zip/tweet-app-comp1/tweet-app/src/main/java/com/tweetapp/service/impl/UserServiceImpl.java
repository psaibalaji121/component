package com.tweetapp.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.entity.Users;
import com.tweetapp.repository.UsersRepository;
import com.tweetapp.requests.CreateUserRequest;
import com.tweetapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UsersRepository userRepository;

	@Override
	public void addUser(CreateUserRequest userRequest) {
		try {
			Users user = new Users();
			String id = UUID.randomUUID().toString();
			user.setId(id);
			user.setFirstName(userRequest.getFirstName());
			user.setLastName(userRequest.getLastName());
			user.setGender(userRequest.getGender());
			user.setEmail(userRequest.getEmail());
			Date dateOfBirth = new SimpleDateFormat("dd-MM-yyyy").parse(userRequest.getDateOfBirth());
			user.setDateOfBirth(dateOfBirth);
			user.setPassword(userRequest.getPassword());
			userRepository.save(user);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public boolean isEmailExists(String email) {
		boolean exists = false;
		List<Users> allUsers = userRepository.findAll();
		for (Users user : allUsers) {
			if (user.getEmail().equals(email)) {
				exists = true;
				break;
			}
		}
		return exists;
	}

	@Override
	public boolean isUserNameAndPasswordExists(String username, String password) {
		boolean canLogin = false;
		List<Users> allUsers = userRepository.findAll();
		for (Users user : allUsers) {
			if (user.getEmail().equals(username)) {
				if (user.getPassword().equals(password)) {
					canLogin = true;
				}
			}
		}
		return canLogin;
	}

	@Override
	public Users findUserByEmail(String email) {
		Users user = userRepository.findByEmail(email);
		return user;
	}

	@Override
	public List<Users> getAllUsers() {
		List<Users> allUsers = userRepository.findAll();
		return allUsers;
	}
	
	@Override
	public void updatePassword(String email, String password) {
		Users user = userRepository.findByEmail(email);
		user.setPassword(password);
		userRepository.save(user);
	}

	@Override
	public void loginUser(String email) {
		Users user = userRepository.findByEmail(email);
		user.setActive(true);
		userRepository.save(user);
	}

	@Override
	public void logoutUser(String email) {
		Users user = userRepository.findByEmail(email);
		user.setActive(false);
		userRepository.save(user);
	}
}
