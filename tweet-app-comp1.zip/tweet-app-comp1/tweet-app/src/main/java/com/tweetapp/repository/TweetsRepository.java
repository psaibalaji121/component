package com.tweetapp.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetapp.entity.Tweets;

public interface TweetsRepository extends MongoRepository<Tweets, String> {

	List<Tweets> findByTweetedUser(String tweetedUser);
	
}
