package com.tweetapp.service;

import java.util.List;

import com.tweetapp.entity.Tweets;

public interface TweetService {

	public void postTweet(Tweets tweet);

	public List<Tweets> findAllTweetsByUser(String tweetedUser);

	public List<Tweets> getAllTweets();
	
}
